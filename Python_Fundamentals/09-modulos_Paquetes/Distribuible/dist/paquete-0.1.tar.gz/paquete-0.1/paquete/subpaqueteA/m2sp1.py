def fm2sp1 ():
    pass

def f2m2sp1():
    pass