# from . import m1sp1,m2sp1

from .m1sp1 import fm1sp1
from .m2sp1 import fm2sp1