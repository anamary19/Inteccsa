from . import convertsystem,modulo
from .convertsystem import dectobin,dectoquin
from .modulo import saludar
from . import subpaqueteA


