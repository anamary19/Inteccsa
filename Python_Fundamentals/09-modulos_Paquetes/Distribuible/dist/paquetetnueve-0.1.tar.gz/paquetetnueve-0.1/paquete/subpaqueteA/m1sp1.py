def fm1sp1 ():
    pass

def f2m1sp1():
    pass

