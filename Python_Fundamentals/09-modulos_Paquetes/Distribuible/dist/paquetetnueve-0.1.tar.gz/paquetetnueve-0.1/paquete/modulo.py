#modulo de ejemplo

pi = 3.1416

def saludar(nombre):
    return f"Hola, {nombre}"

def despedida(nombre):
    return f"Adios, {nombre}"

if __name__ == "__main__":
    print(despedida("Luis"))